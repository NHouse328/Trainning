package com.trainning.consultacep;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText edt_cep,edt_logradouro,edt_numero,edt_complemento,edt_bairro,edt_cidade,edt_estado;
    private Button btn_salvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vincular();
    }

    private void vincular() {
        btn_salvar      = findViewById(R.id.btn_salvar      );
        edt_cep         = findViewById(R.id.edt_cep         );
        edt_logradouro  = findViewById(R.id.edt_logradouro  );
        edt_numero      = findViewById(R.id.edt_numero      );
        edt_complemento = findViewById(R.id.edt_complemento );
        edt_bairro      = findViewById(R.id.edt_bairro      );
        edt_cidade      = findViewById(R.id.edt_cidade      );
        edt_estado      = findViewById(R.id.edt_estado      );
    }

    private void pesquisaCEP() {
        edt_cep.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable cep) {

                if (cep.toString().length() == 8) {
                    retrofit(cep.toString());
                }

            }
        });
    }

    private void retrofit(String cep) {
        Call<Endereco> enderecoCall = new RetrofitConfig().getCEP().buscarCEP(cep);

        enderecoCall.enqueue(new Callback<Endereco>() {
            @Override
            public void onResponse(Call<Endereco> call, Response<Endereco> response) {

                if( response.body() != null) {
                    Endereco endereco = response.body();

                    edt_logradouro.setText(endereco.getLogradouro());
                    edt_bairro.setText(endereco.getBairro());
                    edt_cidade.setText(endereco.getLocalidade());
                    edt_estado.setText(endereco.getUf());
                }
            }

            @Override
            public void onFailure(Call<Endereco> call, Throwable t) {

            }
        });
    }
}
